import React from 'react';
import { View, TouchableOpacity, ScrollView, Text } from 'react-native';
import { useNavigation } from "@react-navigation/native";
import { MaterialIcons } from '@expo/vector-icons';

import styles from './../StyleSheet/styles';

const AdminScreen = ({ route }) => {
  const navigation = useNavigation();
  const userInfo = route.params?.user || {}; 

  function handleLogout() {
    try {
      navigation.replace("Home"); 
      console.log("Sesión cerrada correctamente");
    } catch (error) {
      console.error("Error al cerrar sesión:", error);
    }
  }

  return (
    <ScrollView contentContainerStyle={styles.scrollViewContent}>
      <View style={styles.header}>
        <Text style={styles.title}>IPA Profesor</Text>
        <TouchableOpacity onPress={handleLogout} style={styles.logoutButton}>
          <MaterialIcons name="logout" size={24} color="white" />
        </TouchableOpacity>
      </View>
      <Text style={styles.welcomeText}>Bienvenido, {userInfo.name}!</Text>
      <View style={styles.outerContainer}>
        <View style={styles.container}>
          <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Create')}>
            <Text style={styles.buttonText}>Crear Datos</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('DBView')}>
            <Text style={styles.buttonText}>Consultar Datos</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
};

export default AdminScreen;
